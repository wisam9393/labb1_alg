
#include "parser.h"
#include "lexer.h"




/* Grammar:
	<prgm> = <expr>
	<expr> = <char> | <or>
	<char> = [A-Z a-z]
	<or> = <char> + <char>


*/


parser::parser(std::vector<Token> tokens):tokens(tokens)
{
}

ASTNode* parser::parse() {
	std::cout << "prgmnod" << std::endl;
	prgm* nod;
	nod = new prgm();

	exprnod* child = parseexpr();

	if (child == nullptr)
		return nullptr;
	else
	{
		nod->operands.push_back(child);
	}
	return nod;
}

exprnod* parser::parseexpr()
{
	std::cout << "exprnod" << std::endl;
	exprnod* expr_nod;
	expr_nod = new exprnod();
	//a+b
	auto ch_n = parsechar();
	// nod =  parsechar();
	if (tokens[curent].type == TokenType::OR)
	{
		auto or_nod1 = parseor(ch_n);
		if (or_nod1 != nullptr)
		{
			expr_nod->operands.push_back(or_nod1);
			return expr_nod;
		}
		return nullptr;
	}

	if (tokens[curent].type == TokenType::STAR)
	{
		auto or_nod1 = parsestar(ch_n);
		if (or_nod1 != nullptr)
		{
			expr_nod->operands.push_back(or_nod1);
			return expr_nod;
		}
		return nullptr;
	}

	
	if (ch_n == nullptr && 
		tokens[curent].type == TokenType::DOT)
	{
		std::cout << " DOT DOT DOT" << std::endl;
		auto dot_nod = parsedot();

		if (dot_nod != nullptr)
		{
			expr_nod->operands.push_back(dot_nod);
			return expr_nod;
		}
		return nullptr;
	}
	

	/*
	if (ch_n == nullptr)
		return nullptr;
			*/
	else
	{
		expr_nod->operands.push_back(ch_n);
		return expr_nod;
	}
}

charnode* parser::parsechar()
{
	std::cout << "charnode" << std::endl;

	charnode* nod;
	std::string ord;

	if (tokens[curent].type != TokenType::CHAR)
		return nullptr;
	
	while (tokens[curent].type == TokenType::CHAR) {
		ord += tokens[curent].value;
		curent++;
	}
	nod = new charnode(ord);
	 
		return nod;
}


ornode* parser::parseor(ASTNode* child1)
{
	std::cout << "parseor" << std::endl;
	
	if (child1 == nullptr)
		return nullptr;
	
	if (tokens[curent].type != TokenType::OR)
		return nullptr;

	curent++;
	auto child2 = parsechar();
	if (child2 == nullptr)
		return nullptr;

	ornode* nod = new ornode(child1, child2);

	//nod->operands.push_back(child1);
	return nod;
}


starnode* parser::parsestar(ASTNode* child1)
{
	std::cout << "parsestar" << std::endl;

	if (child1 == nullptr)
		return nullptr;

	/*
	if (child1 == nullptr &&
		tokens[curent].type == TokenType::DOT)
	{
		curent++;
		auto dot_nod = new dotnode();

		if (dot_nod != nullptr)
		{
			expr_nod->operands.push_back(dot_nod);
			return expr_nod;
		}
		return nullptr;
	}
	*/

	if (tokens[curent].type != TokenType::STAR)
		return nullptr;

	curent++;

	starnode* nod = new starnode();

	nod->operands.push_back(child1);
	return nod;
}

dotnode* parser::parsedot()
{
	std::cout << "parsedot" << std::endl;

	if (tokens[curent].type != TokenType::DOT)
		return nullptr;

	curent++;

	// 
	/*
	if (tokens[curent].type != TokenType::STAR)
		std::cout << "NOT STAR efter . " << std::endl;
		return nullptr;
		*/


	dotnode* dotNode = new dotnode();

	return dotNode;

}





/*
std::cout << "charnode" << std::endl;

	charnode* nod;
	std::string ord;

	if (tokens[curent].type != TokenType::CHAR)
		return nullptr;

	while (tokens[curent].type == TokenType::CHAR) {
		ord += tokens[curent].value;
		curent++;
	}
	nod = new charnode(ord);

	return nod;
	*/