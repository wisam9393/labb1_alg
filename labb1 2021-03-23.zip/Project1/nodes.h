#ifndef NODES_H
#define NODES_H

#include "token.h"
#include <algorithm>



/* Grammar:
	<prgm> = <expr>
	<expr> = <char> | <or> 
	<char> = [A-Z a-z]
	<or> = <char> + <char>


*/

struct ASTNode {
	void virtual evaluate() = 0;
	std::string virtual print() { return " "; };
	std::vector<ASTNode*> operands;
};

struct prgm :ASTNode {
	void evaluate() override {
	};

};
//
struct exprnod :ASTNode {
	void evaluate() override {
	};

};

struct charnode :ASTNode {
	std::string stav;
	charnode(std::string stav):stav(stav) {};
	void evaluate() override {
	};
	std::string print() override {
		return stav;
	}
};
//
struct ornode :ASTNode {
	ornode(ASTNode* child1, ASTNode* child2) {
		operands.push_back(child1);
		operands.push_back(child2);
	};

	void evaluate() override {
	};

};


struct starnode :ASTNode {
	void evaluate() override {
	};

};

struct dotnode :ASTNode {
	void evaluate() override {
	};

};

/*
struct dotnode :ASTNode {
	void evaluate() override {
	};

};

struct dotnode :ASTNode {
	void evaluate() override {
	};

};struct dotnode :ASTNode {
	void evaluate() override {
	};

};
struct charnode :ASTNode {
	void evaluate() override {
	};

};


struct charnode :ASTNode {
	void evaluate() override {
	};

};
  */
#endif 