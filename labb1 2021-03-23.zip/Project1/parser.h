
#ifndef PARSER_H
#define PARSER_H

#include <vector>

#include "nodes.h"
#include "token.h"



/* Grammar:
	<prgm> = <expr>
	<expr> = <char> | <add>
	<char> = [A-Z a-z]
	<add> = <expr> + <expr>


*/






/* Grammar:
	<prgm> = <expr>
	<expr> = <char> | <or> |  <star>    
	<char> = [A-Z a-z]
	<or> = <char> + <char>

	<star> = <char><"*"> | <dot><"*">

	<dot> = <".">


	<count> =  <char><{N}> | <dot><{N}>
	<group> = <(> <expr> <)>
	<greedy> =  <star>
	<ignor> = <expr> <"\I">
	<expr> =  <op> | <op><expr>
*/



class parser {
private:
	std::vector<Token> tokens;
	int curent = 0;
public:
	parser(std::vector<Token> tokens);
	ASTNode* parse();
	exprnod* parseexpr();
	charnode* parsechar();
	ornode* parseor(ASTNode* child1);
	starnode* parsestar(ASTNode* child1);
	dotnode* parsedot();
};


#endif

//4.4
