
#ifndef PARSER_H
#define PARSER_H

#include <vector>

#include "nodes.h"
#include "token.h"



/* Grammar:
	<prgm> = <expr>
	<expr> = <char> | <add>
	<char> = [A-Z a-z]
	<add> = <expr> + <expr>


*/


class parser {
private:
	std::vector<Token> tokens;
	int curent = 0;
public:
	ASTNode* parse(std::vector<Token> token);
	ASTNode* parseexpr();
	ASTNode* parsechar();
};


#endif
