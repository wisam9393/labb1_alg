
#include "parser.h"
#include "lexer.h"




/* Grammar:
	<prgm> = <expr>
	<expr> = <char> | <add>
	<char> = [A-Z a-z]
	<add> = <expr> + <expr>


*/


ASTNode* parser::parse(std::vector<Token> token) {
	prgm* nod;
	nod = new prgm();
	ASTNode* child = parseexpr();
	if (child == nullptr)
		return nullptr;
	else
	{
		nod->operands.push_back(child);
	}
	return nod;
}

ASTNode* parser::parseexpr()
{
	ASTNode* nod;
	nod = parsechar();
	if (nod == nullptr)
		return nullptr;
	else
	{
		return nod;
	}
}

ASTNode* parser::parsechar()
{
	ASTNode* nod;
	Token token = tokens[curent];
	if (token.type == TokenType::CHAR) {
		nod = new charnode;
		curent++;
		return nod;
	}
	else
	{
		return nullptr;
	}
	return nullptr;
}

