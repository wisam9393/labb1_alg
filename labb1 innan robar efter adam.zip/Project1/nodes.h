#ifndef NODES_H
#define NODES_H

#include "token.h"
#include <algorithm>



/* Grammar:
	<prgm> = <expr>
	<expr> = <char>
*/

struct ASTNode {
	void virtual evaluate() = 0;
	std::vector<ASTNode*> operands;
};

struct prgm :ASTNode {
	void evaluate() override {
	};

};

struct charnode :ASTNode {
	void evaluate() override {
	};

};
  
#endif 